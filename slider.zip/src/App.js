import "./App.css";
import Footer from "./components/Footer/Footer";
import Header from "./components/Header";
import SimpleSlider from "./components/Slider/SimpleSlider";

function App() {
  return (
    <div className="flex flex-col justify-between h-[100vh]">
      <div>
        <Header />
      </div>
      <div>
        <SimpleSlider />
      </div>
      <div>
        <Footer />
      </div>
    </div>
  );
}

export default App;
