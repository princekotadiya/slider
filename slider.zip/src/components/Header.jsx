import React from 'react'
import HeaderFirstPart from './HeaderFirstPart'
import HeaderMiddle from './HeaderMiddle'
import HeaderBottom from './HeaderBottom'

const Header = () => {
  return (
    <div className=''>

        <div className=''>
            <HeaderFirstPart />
        </div>
        <div>
            <HeaderMiddle />
        </div>
        <div>
            <HeaderBottom />
        </div>
    </div>
  )
}

export default Header
