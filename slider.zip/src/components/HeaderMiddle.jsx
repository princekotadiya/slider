import React, { useState } from "react";
import { CiSearch } from "react-icons/ci";
import { CiUser } from "react-icons/ci";
import { FaCaretDown } from "react-icons/fa";
import { FaShoppingCart } from "react-icons/fa";
import { IoMenu } from "react-icons/io5";
import { MdArrowForwardIos } from "react-icons/md";
import { RiCloseLargeFill } from "react-icons/ri";

const HeaderMiddle = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isOpenSubMenu, setisOpenSubMenu] = useState(false);
  const [searchInputOpen, setsearchInputOpen] = useState(false);
  const [commercialOpen, setcommercialOpen] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [commercialIsActives, setcommercialIsActives] = useState(false);
  const [smallwaresOpen, setSmallwaresOpen] = useState(false);
  const [smallwaresOpenActive, setSmallwaresOpenActive] = useState(false);
  const [storageOpen, setstorageOpen] = useState(false);
  const [storageOpenActive, setstorageOpenActive] = useState(false);
  const [tableTop, settableTop] = useState(false);
  const [tableTopActive, settableTopActive] = useState(false);
  const [disposable, setdisposable] = useState(false);
  const [disposableActive, setdisposableActive] = useState(false);
  const [furniture, setfurniture] = useState(false);
  const [furnitureActive, setfurnitureActive] = useState(false);
  const [janitorial, setjanitorial] = useState(false);
  const [janitorialActive, setjanitorialActive] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const SubMenuToggle = () => {
    setisOpenSubMenu(!isOpenSubMenu);
    setIsActive(!isActive);
  };

  const SubToggleCommercial = () => {
    setcommercialOpen(!commercialOpen);
    setcommercialIsActives(!commercialIsActives);
  };
  const subToggleSmallwares = () => {
    setSmallwaresOpen(!smallwaresOpen);
    setSmallwaresOpenActive(!smallwaresOpenActive);
  };
  const subToggleStorage = () => {
    setstorageOpen(!storageOpen);
    setstorageOpenActive(!storageOpenActive);
  };
  const subToggleTableTop = () => {
    settableTop(!tableTop);
    settableTopActive(!tableTopActive);
  };
  const subToggleDiposable = () => {
    setdisposable(!disposable);
    setdisposableActive(!disposableActive);
  };
  const subToggleFurniture = () => {
    setfurniture(!furniture);
    setfurnitureActive(!furnitureActive);
  };
  const subtoggleJanitorial = () => {
    setjanitorial(!janitorial);
    setjanitorialActive(!janitorialActive);
  };

  const searchToggle = () => {
    setsearchInputOpen((prev) => !prev);
  };
  return (
    <header>
      <div className="flex justify-between items-center p-[15px]">
        <div className="pr-[60px] flex items-center">
          {isMenuOpen ? (
            <RiCloseLargeFill
              className="block lg:hidden mr-[10px] w-[30px] h-[30px]"
              onClick={toggleMenu}
            />
          ) : (
            <IoMenu
              className="block lg:hidden mr-[10px] w-[30px] h-[30px]"
              onClick={toggleMenu}
            />
          )}

          <a
            href="https://www.culinarydepotinc.com/our-supercenter/"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img
              src="./images/group_13_1718894455__64913.original.png"
              alt="Showroom"
              className="w-[150px] h-[56px]"
              width="150"
              height="56"
              loading="lazy"
            />
          </a>
        </div>
        <div className="flex-1 flex justify-start header_inputbox">
          <div className="relative w-[474px] header_search_box">
            <input
              placeholder="I'm looking for..."
              className="focus:outline-none focus:ring-0 border-[1px] border-[#000] w-full h-[50px] rounded-[5px] pl-[15px]"
            />
            <div className="absolute right-[0] top-0 h-[50px] w-[50px] bg-[#d1093f] flex items-center justify-center rounded-tr-[5px] rounded-br-[5px]">
              <CiSearch
                className="text-[#fff]"
                style={{ width: "24px", height: "24px" }}
              />
            </div>
          </div>
        </div>

        <div>
          <nav>
            <ul className="flex justify-between items-center">
              <li className="px-[30px] header_contact">
                <a
                  href="tel:(888) 845-8200"
                  className="text-[#d1093f] text-[16px] font-semibold"
                >
                  <span className="block text-[#000] text-[12px]">
                    CALL US:
                  </span>
                  (888) 845-8200
                </a>
              </li>
              <CiSearch
                style={{ width: "22px", height: "22px" }}
                className="block lg:hidden mr-[8px]"
                onClick={searchToggle}
              />
              <li className="pl-[30px] header_icon_middle">
                <a href="/" className="flex items-center justify-between">
                  <sapn className="mr-[10px]">
                    <CiUser style={{ width: "20px", height: "20px" }} />
                  </sapn>
                  <sapn className="mr-[10px] icon_header">Login</sapn>
                  <sapn>
                    <FaCaretDown className="icon_header w-[17px] h-[20px]" />
                  </sapn>
                </a>
              </li>
              <li className="pl-[30px] header_icon_middle">
                <a href="/" className="flex items-center justify-between">
                  <sapn className="mr-[10px]">
                    <FaShoppingCart style={{ width: "20px", height: "21px" }} />
                  </sapn>
                  <sapn className="mr-[10px] icon_header">My Cart</sapn>
                  <sapn>
                    <FaCaretDown className="icon_header w-[17px] h-[20px]" />
                  </sapn>
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
      {searchInputOpen && (
        <>
          <div className="relative w-[100%] search_bg py-[5px] px-[20px] lg:hidden ">
            <input
              placeholder="I'm looking for..."
              className="focus:outline-none focus:ring-0 border-[1px] border-[#000] w-full h-[50px] rounded-[5px] pl-[15px]"
            />
            <div className="absolute right-[0] top-0 h-[50px] w-[50px] bg-[#d1093f] flex items-center justify-center rounded-tr-[5px] rounded-br-[5px] search_icon">
              <CiSearch
                className="text-[#fff]"
                style={{ width: "24px", height: "24px" }}
              />
            </div>
          </div>
        </>
      )}
      {isMenuOpen && (
        <>
          <div className="lg:hidden">
            <ul className=" px-[15px]">
              <li
                className={`py-[15px] pl-[15px] border-t-[1px] border-[#dbdbdb] flex justify-between items-center ${
                  isActive ? "" : ""
                }
              `}
                onClick={SubMenuToggle}
              >
                <a
                  href="/javascript:void(0)"
                  onClick={(e) => {
                    e.preventDefault();
                    SubMenuToggle();
                  }}
                >
                  <span
                    className={`text-[14px] font-bold ${
                      isActive ? "text-[#d1093f]" : "text-[#000]"
                    }`}
                  >
                    Restaurant Equipment
                  </span>
                </a>
                <MdArrowForwardIos />
              </li>
              {isOpenSubMenu && (
                <div className=" ">
                  <ul className="py-[10px] px-[15px] border-t-[1px] border-[#dbdbdb]">
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#d1093f] ">
                          Shop All
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Cooking Equipment
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Commercial Oven
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Commercial Ice Equipment and Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Food Preparation
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Beverage Equipment
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Commercial Work Tables and Station
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Dishwashing Equipment
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Food Holding and Warming Equipment
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              )}
              <li
                className="py-[15px] pl-[15px] border-t-[1px] border-[#dbdbdb] flex justify-between items-center"
                onClick={SubToggleCommercial}
              >
                <a
                  href="/javascript:void(0)"
                  onClick={(e) => {
                    e.preventDefault();
                    SubToggleCommercial();
                  }}
                >
                  <span
                    className={`text-[14px] font-bold ${
                      commercialIsActives ? "text-[#d1093f]" : "text-[#000]"
                    }`}
                  >
                    Commercial Refrigeration
                  </span>
                </a>
                <MdArrowForwardIos />
              </li>
              {commercialIsActives && (
                <div className=" ">
                  <ul className="py-[10px] px-[15px] border-t-[1px] border-[#dbdbdb]">
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#d1093f] ">
                          Shop All
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Reach-In Refrigerators and Freezers
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Prep Refrigeration
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Bar Refrigerator
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Merchandising and Display Refrigeration
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Undercounter Refrigerators
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Worktop Refrigerators
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Undercounter Freezer
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Worktop Freezers
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              )}
              <li
                className="py-[15px] pl-[15px] border-t-[1px] border-[#dbdbdb] flex justify-between items-center"
                onClick={subToggleSmallwares}
              >
                <a
                  href="/javascript:void(0)"
                  onClick={(e) => {
                    e.preventDefault();
                    subToggleSmallwares();
                  }}
                >
                  <span
                    className={`text-[14px] font-bold ${
                      smallwaresOpen ? "text-[#d1093f]" : "text-[#000]"
                    }`}
                  >
                    Smallwares
                  </span>
                </a>
                <MdArrowForwardIos />
              </li>
              {smallwaresOpen && (
                <div className=" ">
                  <ul className="py-[10px] px-[15px] border-t-[1px] border-[#dbdbdb]">
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#d1093f] ">
                          Shop All
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Kitchen Cutlery
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Cookware
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Food Storage Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Kitchen Hand Tool
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Baking Smallware
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Serving Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Kitchen Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Beverage Supplies
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              )}
              <li
                className="py-[15px] pl-[15px] border-t-[1px] border-[#dbdbdb] flex justify-between items-center"
                onClick={subToggleStorage}
              >
                <a
                  href="/javascript:void(0)"
                  onClick={(e) => {
                    e.preventDefault();
                    subToggleStorage();
                  }}
                >
                  <span
                    className={`text-[14px] font-bold ${
                      storageOpen ? "text-[#d1093f]" : "text-[#000]"
                    }`}
                  >
                    Storage and Transport
                  </span>
                </a>
                <MdArrowForwardIos />
              </li>
              {storageOpen && (
                <div className=" ">
                  <ul className="py-[10px] px-[15px] border-t-[1px] border-[#dbdbdb]">
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#d1093f] ">
                          Shop All
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Carts
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Dinnerware Storage and Transports
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Ice Transport Buckets and Mobile Ice Bins
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Industrial Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Insulated Food Carriers and Beverage Dispensers
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Delivery Bag Accessories
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Storage Rack
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Trucks and Dollies
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              )}
              <li
                className="py-[15px] pl-[15px] border-t-[1px] border-[#dbdbdb] flex justify-between items-center"
                onClick={subToggleTableTop}
              >
                <a
                  href="/javascript:void(0)"
                  onClick={(e) => {
                    e.preventDefault();
                    subToggleTableTop();
                  }}
                >
                  <span
                    className={`text-[14px] font-bold ${
                      tableTop ? "text-[#d1093f]" : "text-[#000]"
                    }`}
                  >
                    Tabletop
                  </span>
                </a>
                <MdArrowForwardIos />
              </li>
              {tableTop && (
                <div className=" ">
                  <ul className="py-[10px] px-[15px] border-t-[1px] border-[#dbdbdb]">
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#d1093f] ">
                          Shop All
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Dinnerware
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Flatware
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Beverageware
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Condiment Holders and Dispensers
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Menu Holders and Guest Check Presenters
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Tabletop Beverage Service
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Tabletop Display and Decor
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Asian Restaurant Tabletop Supplies
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              )}
              <li
                className="py-[15px] pl-[15px] border-t-[1px] border-[#dbdbdb] flex justify-between items-center"
                onClick={subToggleDiposable}
              >
                <a
                  href="/javascript:void(0)"
                  onClick={(e) => {
                    e.preventDefault();
                    subToggleDiposable();
                  }}
                >
                  <span
                    className={`text-[14px] font-bold ${
                      disposable ? "text-[#d1093f]" : "text-[#000]"
                    }`}
                  >
                    Disposable
                  </span>
                </a>
                <MdArrowForwardIos />
              </li>
              {disposable && (
                <div className=" ">
                  <ul className="py-[10px] px-[15px] border-t-[1px] border-[#dbdbdb]">
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#d1093f] ">
                          Shop All
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Catering Disposables
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Disposable Bakery Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Disposable Chopstick
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Disposable Concession Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Disposable Food Packaging Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Disposable Host and Server Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Eco-Friendly Disposable
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Food Safety Disposables
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              )}
              <li
                className="py-[15px] pl-[15px] border-t-[1px] border-[#dbdbdb] flex justify-between items-center"
                onClick={subToggleFurniture}
              >
                <a
                  href="/javascript:void(0)"
                  onClick={(e) => {
                    e.preventDefault();
                    subToggleFurniture();
                  }}
                >
                  <span
                    className={`text-[14px] font-bold ${
                      furniture ? "text-[#d1093f]" : "text-[#000]"
                    }`}
                  >
                    Furniture
                  </span>
                </a>
                <MdArrowForwardIos />
              </li>
              {furniture && (
                <div className=" ">
                  <ul className="py-[10px] px-[15px] border-t-[1px] border-[#dbdbdb]">
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#d1093f] ">
                          Shop All
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Restaurant Table
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Restaurant Seating
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Commercial Outdoor Furnitures
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          School Furniture
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Folding Chairs and Tables
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Early Learning Furniture and Supplies
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Commercial Decors
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Coat Rack
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              )}
              <li
                className="py-[15px] pl-[15px] border-t-[1px] border-[#dbdbdb] flex justify-between items-center"
                onClick={subtoggleJanitorial}
              >
                <a
                  href="/javascript:void(0)"
                  onClick={(e) => {
                    e.preventDefault();
                    subtoggleJanitorial();
                  }}
                >
                  <span
                    className={`text-[14px] font-bold ${
                      janitorial ? "text-[#d1093f]" : "text-[#000]"
                    }`}
                  >
                    Janitorial Supply
                  </span>
                </a>
                <MdArrowForwardIos />
              </li>
              {janitorial && (
                <div className=" ">
                  <ul className="py-[10px] px-[15px] border-t-[1px] border-[#dbdbdb]">
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#d1093f] ">
                          Shop All
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Cleaning Chemicals
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          First Aid Kit
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          First Aid Supply
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Cleaning Supplies and Tools
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Commercial Floor Mat
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Facility Maintenance and Sanitation
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Floor Care Supply
                        </span>
                      </a>
                    </li>
                    <li className="py-[7px]">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[14px] font-normal text-[#000] ">
                          Hand Sanitizer and Soap
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              )}
            </ul>
          </div>
        </>
      )}
    </header>
  );
};

export default HeaderMiddle;
