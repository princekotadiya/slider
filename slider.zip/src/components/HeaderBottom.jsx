import React from "react";

const HeaderBottom = () => {
  return (
    <div>
      <div className="bg-[#d1093f] footer_bottom_main">
        <ul className="flex justify-between items-center">
          <li className="py-[18px] px-[19px] header_bottom">
            <a
              href="/"
              className=" text-[12px] text-[#fff] font-medium "
            >
              Restaurant Equipment
            </a>
          </li>
          <li className="py-[18px] px-[19px] header_bottom">
            <a href="/" className=" text-[12px] text-[#fff] font-medium ">
              Commercial Refrigerationt
            </a>
          </li>
          <li className="py-[18px] px-[19px] header_bottom">
            <a href="/" className=" text-[12px] text-[#fff] font-medium  ">
              Smallwares
            </a>
          </li>
          <li className="py-[18px] px-[19px] header_bottom">
            <a href="/" className=" text-[12px] text-[#fff] font-medium  ">
              Storage and Transport
            </a>
          </li>
          <li className="py-[18px] px-[19px] header_bottom">
            <a href="/" className=" text-[12px] text-[#fff] font-medium  ">
              Tabletop
            </a>
          </li>
          <li className="py-[18px] px-[19px] header_bottom">
            <a href="/" className=" text-[12px] text-[#fff] font-medium  ">
              Disposable
            </a>
          </li>
          <li className="py-[18px] px-[19px] header_bottom">
            <a href="/" className=" text-[12px] text-[#fff] font-medium  ">
              Furniture
            </a>
          </li>
          <li className="py-[18px] px-[19px] header_bottom">
            <a href="/" className=" text-[12px] text-[#fff] font-medium  ">
              Janitorial Supply
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default HeaderBottom;
