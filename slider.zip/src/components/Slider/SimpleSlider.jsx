import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const PreviousBtn = (props) => {
  const { className, onClick } = props;
  return (
    <div className={className} onClick={onClick}>
      <button className="prev-btn">
        &#8592; {/* Left Arrow Symbol */}
      </button>
    </div>
  );
};

const NextBtn = (props) => {
  const { className, onClick } = props;
  return (
    <div className={className} onClick={onClick}>
      <button className="next-btn">
        &#8594; {/* Right Arrow Symbol */}
      </button>
    </div>
  );
};

const SimpleSlider = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    // autoplay: true,
    // autoplaySpeed: 2000,
    nextArrow: <NextBtn />,
    prevArrow: <PreviousBtn />,
  };

  return (
    <div className="slider-container">
      <Slider {...settings}>
        <div>
          <img src="./images/beverage-air-banner-1350-404.jpg" alt="Slide 1" />
        </div>
        <div>
          <img src="./images/pro-banner-desktop-1350.jpg" alt="Slide 2" />
        </div>
        <div>
          <img src="./images/allmont-banner-1350.jpg" alt="Slide 3" />
        </div>
       
      </Slider>
    </div>
  );
};

export default SimpleSlider;
