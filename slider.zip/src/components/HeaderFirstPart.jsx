import React from "react";

const HeaderFirstPart = () => {
  return (
    <div>
      <div className="flex justify-between px-[15px] header_firstpart h-[38px] items-center header_firstpart">
        <div className="left_side">
          <a
            href="https://www.culinarydepotinc.com/our-supercenter/"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img
              src="./images/showroom.png" 
              alt="Showroom"
              className="w-[194px] h-[28px]"
              width="194"  
              height="28"
              loading="lazy" 
            />
          </a>
        </div>

        <div className="right_side">
          <ul className="flex justify-between items-center">
            <li className="bg-[#282b30] rounded-[15px] my-[5px] ml-[10px] mr-[20px]">
              <div className="flex items-center px-[5px] py-[3px]">
                <img
                  src="./images/download.png" 
                  alt="Download"
                  className="w-[52px] h-[24px]"
                  width="52"  
                  height="24"
                  loading="lazy" 
                />
                <span className="text-[#fff] text-[10px] font-medium px-[15px]">
                  Sign up for pro and receive more
                </span>
                <button className="text-[#fff] text-[10px] font-bold w-[80px] h-[20px] border-[1px] border-[#fff] rounded-[15px] header_btn">
                  Go Pro Now
                </button>
              </div>
            </li>

            <li className="px-[10px] py-[5px] mr-[10px] text-[12px] text-[#000] font-semibold">
              <a href="/">Live Chat</a>
            </li>

            <li className="px-[10px] py-[5px] text-[12px] text-[#000] font-semibold">
              <a href="/">About Us</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default HeaderFirstPart;
