import React, { useEffect, useState } from "react";
import { RiFacebookFill } from "react-icons/ri";
import { IoIosArrowDown } from "react-icons/io";
import { IoIosMailOpen } from "react-icons/io";
import { CiSearch } from "react-icons/ci";
import { FiTwitter } from "react-icons/fi";
import { FaPinterest } from "react-icons/fa";
import { SlSocialLinkedin } from "react-icons/sl";
import { MdOutlineWifi } from "react-icons/md";
const Footer = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 1080) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    handleResize();

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const [footerVisible, setfooterVisible] = useState(false);
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 1090) {
        setfooterVisible(true);
      } else {
        setfooterVisible(false);
      }
    };

    handleResize();

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  const [isOpen, setIsOpen] = useState(false);
  const [customerOpen, setcustomerOpen] = useState(false);
  const [accountOpen, setaccountOpen] = useState(false);

  const toggleDropdown = () => {
    setIsOpen((prev) => !prev);
  };
  const toggleCustomer = () => {
    setcustomerOpen(!customerOpen);
  };
  const toggleAccount = () => {
    setaccountOpen(!accountOpen);
  };
  return (
    <>
      <div className="bg-[#d1093f] mt-52 footer_email_send">
        <div className="container py-[70px]">
          <div className="flex justify-between">
            <div className="flex">
              <div className="mr-[30px]">
                <IoIosMailOpen
                  style={{ width: "60px", height: "60px", color: "#fff" }}
                />
              </div>
              <div>
                <h3 className="text-[26px] text-[#fff] leading-[32px] mb-[5px] font-semibold ">
                  EXCLUSIVE SAVINGS FOR MEMBERS
                </h3>
                <p className="font-medium text-[18px] text-[#fff]">
                  Sign Up For Special Offers, Promo Codes
                </p>
              </div>
            </div>

            <div className="relative w-[532px] footer_subscribe">
              <input
                placeholder="Enter your email here..."
                className="focus:outline-none focus:ring-0 border-[1px] w-full border-[#000] h-[50px] rounded-[5px] pl-[15px]"
              />
              <div className="absolute right-[0] top-0 h-[50px] w-[100px] bg-[#000] flex items-center justify-center rounded-tr-[5px] rounded-br-[5px] footer_sub_btn">
                <button className="text-[#fff]">Subscribe</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {footerVisible && (
        <>
          <div className="mt-[200px]">
            <div className="bg-[#d1093f] relative">
              <div className="flex justify-center relative">
                <div className="w-[100px] h-[100px] rounded-[50%] bg-[#fff] flex justify-center items-center absolute top-[-50px] footer_logo">
                  <IoIosMailOpen
                    style={{ width: "60px", height: "60px", color: "red" }}
                  />
                </div>
              </div>

              <div className="flex justify-center">
                <div className="pt-[74px] pb-[30px]">
                  <h3 className="text-[4vw] sm:text-[22px] flex justify-center text-[#fff] leading-[28px] mb-[5px] font-semibold">
                    EXCLUSIVE SAVINGS FOR MEMBERS
                  </h3>
                  <p className="font-medium text-[3vw] sm:text-[16px] text-[#fff] flex justify-center">
                    Sign Up For Special Offers, Promo Codes
                  </p>
                </div>
              </div>

              <div className="relative mx-[30px] pb-[30px]">
                <input
                  placeholder="Enter your email here..."
                  className="focus:outline-none focus:ring-0 border-[1px] w-full border-[#000] h-[50px] rounded-[5px] pl-[15px]"
                />
                <div className="absolute right-[0] top-0 h-[50px] w-[100px] bg-[#000] flex items-center justify-center rounded-tr-[5px] rounded-br-[5px] ">
                  <button className="text-[#fff]">Subscribe</button>
                </div>
              </div>
              
            </div>
          </div>
        </>
      )}

      <div className="bg-[#202020]">
        <div className="border-b-[1px] border-[#515151] footer_content">
          <div className=" pt-[50px] pb-[50px] flex container ">
            <div className="w-[26%] border-r-[1px] border-[#515151] h-[308px]">
              <div>
                <img
                  src="./images/logo-white-footer.png"
                  alt="Showroom"
                  className="w-[180px] h-[65px]"
                  width="180"
                  height="65"
                  loading="lazy"
                />
              </div>
              <div className="mt-[10px] mb-[10px]">
                <a href="/" target="_blank" rel="noopener noreferrer">
                  <span className="text-[14px] font-normal text-[#fff] leading-[20px] block">
                    Culinary Depot
                  </span>
                </a>
                <a href="/" target="_blank" rel="noopener noreferrer">
                  <span className="text-[14px] font-normal text-[#fff] leading-[20px]">
                    67 Route 59 Spring Valley, NY 10977
                  </span>
                </a>
              </div>
              <a href="/" target="_blank" rel="noopener noreferrer">
                <span className="text-[14px] font-normal text-[#fff] leading-[20px]">
                  (888) 845-8200
                </span>
              </a>
              <div className="mt-[40px]">
                <div className="mb-[10px] leading-[20px] font-medium text-[#fff] text-[17px]">
                  Let's Connect
                </div>
              </div>
              <div>
                <ul className="flex">
                  <li className="w-[37px] h-[37px] mr-[10px] text-[#fff] border-[1px] border-[#fff] flex justify-center items-center footer_icon">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <RiFacebookFill className="w-[17px] h-[17px]" />
                    </a>
                  </li>
                  <li className="w-[37px] h-[37px] mr-[10px] text-[#fff] border-[1px] border-[#fff] flex justify-center items-center footer_icon">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <img
                        src="./images/1161953_instagram_icon.svg"
                        alt="instagram-icon"
                        loading="lazy"
                        className="h-[17px] w-[17px] text-white"
                      />
                    </a>
                  </li>
                  <li className="w-[37px] h-[37px] mr-[10px] text-[#fff] border-[1px] border-[#fff] flex justify-center items-center footer_icon">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <FiTwitter style={{width:"17px",height:"17px", color:"#fff"}} />
                    </a>
                  </li>
                  <li className="w-[37px] h-[37px] mr-[10px] text-[#fff] border-[1px] border-[#fff] flex justify-center items-center footer_icon">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <FaPinterest style={{width:"17px",height:"17px"}}/>
                    </a>
                  </li>
                  <li className="w-[37px] h-[37px] mr-[10px] text-[#fff] border-[1px] border-[#fff] flex justify-center items-center footer_icon">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <SlSocialLinkedin style={{width:"17px",height:"17px"}}/>
                      {/* <img
                        src="./images/1820468_brand_linkedin_logo_network_social_icon (1).svg"
                        alt="linkedin-icon"
                        loading="lazy"
                        className="w-[17px] h-[17px]"
                      /> */}
                    </a>
                  </li>
                  <li className="w-[37px] h-[37px] mr-[10px] text-[#fff] border-[1px] border-[#fff] flex justify-center items-center footer_icon">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <MdOutlineWifi style={{width:"17px",height:"17px"}}/>
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            <div className="w-[20%] px-[20px] border-r-[1px] border-[#515151]">
              <h3 className="font-medium text-[17px] text-[#fff] pb-[10px] border-b-[1px] border-[#515151] uppercase mb-[20px]">
                Corporate Info
              </h3>
              <div>
                <ul>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        About Us
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Our Supercenter
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Blog
                      </span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            <div className="w-[20%] px-[20px] border-r-[1px] border-[#515151]">
              <h3 className="font-medium text-[17px] text-[#fff] pb-[10px] border-b-[1px] border-[#515151] uppercase mb-[20px]">
                Customer Service
              </h3>
              <div>
                <ul>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Contact Us
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff] block">
                        Commercial Kitchen
                      </span>
                      <span className="text-[14px] font-normal text-[#fff]">
                        Equipment Leasing
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Returns & Exchanges
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Privacy Policy
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Credit Application Form
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Shipping Information
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Build Your Own Bar
                      </span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            <div className="w-[20%] px-[20px] border-r-[1px] border-[#515151]">
              <h3 className="font-medium text-[17px] text-[#fff] pb-[10px] border-b-[1px] border-[#515151] uppercase mb-[20px]">
                Account
              </h3>
              <div>
                <ul>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        My Account
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Orders
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        BAddresses
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Shopping Cart
                      </span>
                    </a>
                  </li>
                  <li className="mb-[10px]">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className=""
                    >
                      <span className="text-[14px] font-normal text-[#fff]">
                        Wishlist
                      </span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            <div className="w-[14%] flex items-end flex-col">
              <div className="mb-[20px]">
                <img
                  src="./images/review-img-new.png"
                  alt="Showroom"
                  className="w-[115px] h-[43px]"
                  width="115"
                  height="43"
                  loading="lazy"
                />
              </div>
              <div>
                <img
                  src="./images/bbb-logo-new.png"
                  alt="Showroom"
                  className="w-[115px] h-[43px]"
                  width="180"
                  height="43"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="py-[12px] flex justify-between container footer_copyright">
          <div>
            <p>
              <a
                href="/"
                target="_blank"
                rel="noopener noreferrer"
                className=""
              >
                <span className="text-[12px] text-[#fff]">
                  Developed by Culinary Depot
                </span>
              </a>
            </p>
          </div>
          <div>
            <p>
              <span className="text-[12px] text-[#fff]">
                Copyright © 1995 to 2024 Culinary Depot. All rights reserved.
              </span>
            </p>
          </div>
        </div>

        {isVisible && (
          <>
            <div className="pt-[50px]">
              <div className="px-[25px] pb-[30px]">
                <div className="pb-[25px]">
                  <div className="flex justify-center">
                    <img
                      src="./images/logo-white-footer.png"
                      alt="Showroom"
                      className="w-[180px] h-[65px]"
                      width="180"
                      height="65"
                      loading="lazy"
                    />
                  </div>
                  <div className="mt-[10px] mb-[10px]">
                    <div className="flex justify-center">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[18px] font-normal text-[#fff] leading-[20px]">
                          Culinary Depot
                        </span>
                      </a>
                    </div>
                    <div className="flex justify-center">
                      <a href="/" target="_blank" rel="noopener noreferrer">
                        <span className="text-[18px] font-normal text-[#fff] leading-[20px]">
                          67 Route 59 Spring Valley, NY 10977
                        </span>
                      </a>
                    </div>
                  </div>
                  <div className="flex justify-center">
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-center"
                    >
                      <span className="text-[18px] font-normal text-[#fff] leading-[20px]">
                        (888) 845-8200
                      </span>
                    </a>
                  </div>
                </div>

                <div
                  className="pt-[15px] pb-[15px] border-b-[1px] border-[#fff]"
                  onClick={toggleDropdown}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-[#fff] uppercase  text-[16px]">
                        Corporate Info
                      </h4>
                    </div>
                    <div>
                      <IoIosArrowDown className="text-[#fff]" />
                    </div>
                  </div>
                </div>
                {isOpen && (
                  <>
                    <div>
                      <ul className="pt-[20px] pb-[20px]">
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              About Us
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Our Supercenter
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Blog
                            </span>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </>
                )}

                <div
                  className="pt-[15px] pb-[15px] border-b-[1px] border-[#fff]"
                  onClick={toggleCustomer}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-[#fff] text-[16px] uppercase">
                        Customer Service
                      </h4>
                    </div>
                    <div>
                      <IoIosArrowDown className="text-[#fff]" />
                    </div>
                  </div>
                </div>
                {customerOpen && (
                  <>
                    <div>
                      <ul className="pt-[20px] pb-[20px]">
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Contact Us
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Commercial Kitchen Equipment Leasing
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Returns & Exchanges
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Privacy Policy
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Credit Application Form
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Shipping Information
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Build Your Own Bar
                            </span>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </>
                )}

                <div
                  className="pt-[15px] pb-[15px] border-b-[1px] border-[#fff] "
                  onClick={toggleAccount}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-[#fff]  text-[16px] uppercase">
                        account
                      </h4>
                    </div>
                    <div>
                      <IoIosArrowDown className="text-[#fff]" />
                    </div>
                  </div>
                </div>

                {accountOpen && (
                  <>
                    <div>
                      <ul className="pt-[20px] pb-[20px]">
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              My Account
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Orders
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Addresses
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Shopping Cart
                            </span>
                          </a>
                        </li>
                        <li className="mb-[10px]">
                          <a href="/" target="_blank" rel="noopener noreferrer">
                            <span className="text-[14px] font-normal text-[#fff] ">
                              Wishlist
                            </span>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </>
                )}
              </div>
            </div>
          </>
        )}
      </div>
      {isVisible && (
        <>
          <div className="flex items-center px-[20px] py-[10px]">
            <div className="flex flex-1 justify-center">
              <img
                src="./images/review-img-new.png"
                alt="Showroom"
                className="w-[115px] h-[43px]"
                width="115"
                height="43"
                loading="lazy"
              />
            </div>
            <div>
              <img
                src="./images/bbb-logo-new.png"
                alt="Showroom"
                className="w-[115px] h-[43px]"
                width="180"
                height="43"
                loading="lazy"
              />
            </div>
          </div>

          <div className="bg-[#bfbfbf] px-[20px] py-[10px]">
            <div className="flex justify-center">
              <p>
                <a
                  href="/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className=""
                >
                  <span className="text-[12.5px] text-[#000] font-medium">
                    Developed by Culinary Depot
                  </span>
                </a>
              </p>
            </div>
            <div className="flex justify-center">
              <p>
                <span className="text-[12.5px] text-[#000] font-medium ">
                  Copyright © 1995 to 2024 Culinary Depot. All rights reserved.
                </span>
              </p>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default Footer;
